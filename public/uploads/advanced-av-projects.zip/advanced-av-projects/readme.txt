Advanced audio-visual processing portfolio by Tomas Jasevicius.

This folder contains only html and javascript files which are used to build advanced audio visual processing portfolio at http://av.tomasj.uk/. Style sheets, 3rd party libraries and other files are required to run this project locally.

If you’re interested running it locally please find full code base at https://github.com/jasetom/advanced-av-portfolio-website